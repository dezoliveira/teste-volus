# Social Card
#### Visão Geral
Bem vindo ao Social Card, Card Social que exibe informações de um usuário.
Suas funcionalidades são:

- Exibição (Front) de um Card foto do usuário, uma breve descrição, hashtags e um botão de Follow.

Acesse: https://social-card-nine.vercel.app/

---
#### Tecnologias 
- HTML/CSS
- Booststrap
- Vite

--- 
#### Como Rodar o Projeto (local)
- git clone https://www.github.com/dezoliveira/social-card
- cd social-card
- npm install
- npm run dev
- acesse: http://localhost:5173/