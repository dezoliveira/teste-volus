# React Example
#### Visão Geral
App de exemplo para ilustrar a componetização no React.

Acesse: https://github.com/dezoliveira/react-example

---
#### Tecnologias 
- React
- Vite

--- 
#### Como Rodar o Projeto (local)
- git clone https://www.github.com/dezoliveira/react-example
- cd react-example
- npm install
- npm run dev